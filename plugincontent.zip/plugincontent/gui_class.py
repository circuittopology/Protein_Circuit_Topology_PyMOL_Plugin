from pymol import cmd  # pylint: disable=import-error, no-name-in-module

from pymol.Qt import QtWidgets, QtCore  # pylint: disable=import-error, no-name-in-module

from .utils.get_values import get_values, get_local_values, get_multiple_values, get_vis_vals
from .utils.clear_file import clear_selected_single_file, clear_selected_local_file
from .utils.directory import (
    choose_file,
    choose_local_file,
    choose_output_dir,
    choose_local_output_dir,
    choose_input_dir_multi,
    choose_output_dir_multi,
)

from .utils.object_change import handle_standard_object_change, handle_local_object_change
from .utils.non_polymer import show_warning_dialog
from .utils.residues import get_residue_range, update_residue_range
from .utils.helpers import update_chain_combo_box, init_timers, object_exists
from .utils.config import SECTION_STYLESHEET
from .utils.updates import update_list, update_local_list, update_output_widgets, update_output_widgets_local, update_output_widgets_multi
from .utils.trajectory import select_mol_file, select_xtc_file, export_frames_from_traj

from .analysis.local_ct_analysis import run_local_ct
from .analysis.single_file_analysis import run_standard_analysis
from .analysis.single_frame_analysis import run_single_frame_analysis, toggle_frame_controls
from .analysis.multiple_file_analysis import run_multi_analysis
from .analysis.visualization import visualize_molecule

from .tabs.local_tab import init_local_tab
from .tabs.single_file_tab import init_single_file_tab
from .tabs.multiple_file_tab import init_multi_file_tab

if not hasattr(cmd, "object_exists"):
    setattr(cmd, "object_exists", object_exists)

class CTDialog(QtWidgets.QDialog):
    # adding class methods from utils
    # get_values.py
    @QtCore.pyqtSlot()
    def get_values(self):
        return get_values(self)

    @QtCore.pyqtSlot()
    def get_local_values(self):
        return get_local_values(self)
    
    @QtCore.pyqtSlot()
    def get_multiple_values(self):
        return get_multiple_values(self)
    
    @QtCore.pyqtSlot()
    def get_vis_vals(self):
        return get_vis_vals(self)
    
    # clear_file.py
    @QtCore.pyqtSlot()
    def clear_selected_local_file(self):
        clear_selected_local_file(self)

    @QtCore.pyqtSlot()
    def clear_selected_single_file(self):
        clear_selected_single_file(self)

    # directory.py
    @QtCore.pyqtSlot()
    def choose_file(self):
        choose_file(self)

    @QtCore.pyqtSlot()
    def choose_local_file(self):
        choose_local_file(self)

    @QtCore.pyqtSlot()
    def choose_output_dir(self):
        choose_output_dir(self)

    @QtCore.pyqtSlot()
    def choose_local_output_dir(self):
        choose_local_output_dir(self)

    @QtCore.pyqtSlot()
    def choose_input_dir_multi(self):
        choose_input_dir_multi(self)
    
    @QtCore.pyqtSlot()
    def choose_output_dir_multi(self):
        choose_output_dir_multi(self)

    # object_change.py
    @QtCore.pyqtSlot()
    def handle_local_object_change(self, obj_name=None):
        if obj_name is None:
            obj_name = self.local_dropdown_objects.currentText()
        handle_local_object_change(self, obj_name)

    @QtCore.pyqtSlot()
    def handle_standard_object_change(self, obj_name=None):
        if obj_name is None:
            obj_name = self.dropdown_objects.currentText()
        handle_standard_object_change(self, obj_name)

    # non_polymer.py
    @QtCore.pyqtSlot()
    def show_warning_dialog(self):
        show_warning_dialog(self)

    # residues.py
    @QtCore.pyqtSlot()
    def get_residue_range(self, obj_name=None):
        if obj_name is None:
            obj_name = self.local_dropdown_objets.currentText()
        get_residue_range(self, obj_name)

    @QtCore.pyqtSlot()
    def update_residue_range(self):
        update_residue_range(self)

    # helpers.py
    @QtCore.pyqtSlot()
    def update_chain_combo_box(self):
        update_chain_combo_box(self)

    @QtCore.pyqtSlot()
    def init_timers(self):
        init_timers(self)

    # updates.py
    @QtCore.pyqtSlot()
    def update_list(self):
        update_list(self)

    @QtCore.pyqtSlot()
    def update_local_list(self):
        update_local_list(self)

    @QtCore.pyqtSlot()
    def update_output_widgets(self):
        update_output_widgets(self)

    @QtCore.pyqtSlot()
    def update_output_widgets_local(self):
        update_output_widgets_local(self)

    @QtCore.pyqtSlot()
    def update_output_widgets_multi(self):
        update_output_widgets_multi(self)
    
    # trajectory.py
    @QtCore.pyqtSlot()
    def select_mol_file(self):
        select_mol_file(self)
    
    @QtCore.pyqtSlot()
    def select_xtc_file(self):
        select_xtc_file(self)

    @QtCore.pyqtSlot()
    def export_frames_from_traj(self):
        export_frames_from_traj(self)

    # tabs
    @QtCore.pyqtSlot()
    def init_local_tab(self):
        init_local_tab(self)

    @QtCore.pyqtSlot()
    def init_single_file_tab(self):
        init_single_file_tab(self)

    @QtCore.pyqtSlot()
    def init_multi_file_tab(self):
        init_multi_file_tab(self)

    # analysis functions
    @QtCore.pyqtSlot()
    def run_local_ct(self):
        run_local_ct(self)

    @QtCore.pyqtSlot()
    def run_standard_analysis(self):
        run_standard_analysis(self)

    @QtCore.pyqtSlot()
    def run_single_frame_analysis(self):
        run_single_frame_analysis(self)

    @QtCore.pyqtSlot()
    def run_multi_analysis(self):
        run_multi_analysis(self)

    @QtCore.pyqtSlot()
    def visualize_molecule(self, contact_type):
        visualize_molecule(self, contact_type)
    
    @QtCore.pyqtSlot(bool)
    def toggle_frame_controls(self, enabled):
        toggle_frame_controls(self, enabled=enabled)
    
    def __init__(self, parent=None):
        super().__init__(parent)

        self.current_objects = set()
        self.current_local_objects = set()

        self.setWindowTitle("Circuit Topology Tool")
        self.setGeometry(100, 100, 480, 540)
        self.setStyleSheet(SECTION_STYLESHEET)

        self.init_ui()
        self.init_timers()
    
    def init_ui(self):
        self.tab_widget = QtWidgets.QTabWidget()

        self.local_tab = QtWidgets.QWidget()
        self.single_file_tab = QtWidgets.QWidget()
        self.multi_file_tab = QtWidgets.QWidget()

        self.tab_widget.addTab(self.local_tab, "Local Circuit Topology")
        self.tab_widget.addTab(self.single_file_tab, "Single‑File Analysis")
        self.tab_widget.addTab(self.multi_file_tab, "Multi‑File Analysis")

        self.init_local_tab()
        self.init_single_file_tab()
        self.init_multi_file_tab()

        main_layout = QtWidgets.QVBoxLayout()
        main_layout.addWidget(self.tab_widget)
        self.setLayout(main_layout)
